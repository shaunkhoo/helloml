# helloml
Simple ML for beginners.

## Dependencies
```
python>=3.8
```

Install dependencies by running:
```
pip install -r requirements.txt
```

## How to Use: Predicting survivors on the Titanic shipwreck

Run `titanic_demo.ipynb`.